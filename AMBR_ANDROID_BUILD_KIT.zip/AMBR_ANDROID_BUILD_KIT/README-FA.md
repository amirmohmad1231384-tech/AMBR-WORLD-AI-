# بسته ساخت اندروید AMBR WORLD AI

این پروژه یک پوسته Android WebView برای نمایش فایل HTML اصلی AMBR است و گردش ساخت APK آن با GitHub Actions آماده شده است.

## ساخت APK
1. تمام محتویات این پوشه، از جمله پوشه مخفی `.github`، باید در ریشه مخزن GitHub قرار گیرند.
2. در GitHub وارد زبانه Actions شوید و workflow با نام Build AMBR APK را اجرا کنید.
3. پس از موفقیت، artifact با نام AMBR-Android-debug را دانلود و از ZIP خارج کنید.
4. فایل app-debug.apk را روی گوشی نصب کنید.

## محدودیت مهم
این بسته هنوز موتور Python و موتور بومی llama.cpp/Qwen را داخل APK ادغام نمی‌کند. بنابراین این خروجی صرفاً پوسته نصب‌شدنی برای رابط HTML است و پاسخ‌دهی آفلاین Qwen را تضمین نمی‌کند. ساخت APK نیز باید در GitHub Actions اجرا و تأیید شود.
