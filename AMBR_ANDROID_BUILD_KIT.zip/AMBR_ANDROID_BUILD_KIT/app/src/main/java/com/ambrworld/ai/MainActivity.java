package com.ambrworld.ai;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<Uri[]> uploadCallback;
  private static final int FILE_PICKER = 1001;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web = new WebView(this);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
        if (uploadCallback != null) uploadCallback.onReceiveValue(null);
        uploadCallback = cb;
        Intent i = p.createIntent();
        try { startActivityForResult(i, FILE_PICKER); return true; }
        catch (Exception e) { uploadCallback = null; return false; }
      }
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int req, int res, Intent data) {
    super.onActivityResult(req,res,data);
    if (req == FILE_PICKER && uploadCallback != null) {
      Uri[] result = WebChromeClient.FileChooserParams.parseResult(res,data);
      uploadCallback.onReceiveValue(result); uploadCallback = null;
    }
  }
  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
